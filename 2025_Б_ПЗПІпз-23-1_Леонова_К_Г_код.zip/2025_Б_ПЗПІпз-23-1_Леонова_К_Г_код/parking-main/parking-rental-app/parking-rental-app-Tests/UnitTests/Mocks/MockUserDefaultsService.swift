//
//  MockUserDefaultsService.swift
//  parking-rental-app-Tests
//
//

import Foundation
@testable import parking_rental_app

final class MockUserDefaultsService: UserDefaultsContainer {
    var date: Date?
    var theme: Int = Theme.device.rawValue
}
