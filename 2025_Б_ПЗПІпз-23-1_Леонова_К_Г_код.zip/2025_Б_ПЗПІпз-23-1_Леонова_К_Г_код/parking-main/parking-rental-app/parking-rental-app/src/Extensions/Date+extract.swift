//
//  Date+extract.swift
//  parking-rental-app
//
//

import Foundation

extension Date {
    func extractDate() -> String {
        return "\("\(self)".prefix(10))"
    }
}
