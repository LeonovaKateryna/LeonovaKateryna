//
//  UIColor+themeColors.swift
//  parking-rental-app
//
//

import UIKit

extension UIColor {
    var light: UIColor {
        resolvedColor(with: .init(userInterfaceStyle: .light))
    }
    
    var dark: UIColor {
        resolvedColor(with: .init(userInterfaceStyle: .dark))
    }
}
