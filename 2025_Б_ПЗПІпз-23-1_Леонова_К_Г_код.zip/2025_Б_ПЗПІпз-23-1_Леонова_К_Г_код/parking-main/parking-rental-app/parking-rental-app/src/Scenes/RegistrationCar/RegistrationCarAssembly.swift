//
//  RegistrationCarAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum RegistrationCarAssembly {
    static func build() -> UIViewController {
        let router: RegistrationCarRouter = RegistrationCarRouter()
        let presenter: RegistrationCarPresenter = RegistrationCarPresenter()
        let interactor: RegistrationCarInteractor = RegistrationCarInteractor(presenter: presenter)
        let viewController: RegistrationCarViewController = RegistrationCarViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
