//
//  RegistrationCarRouter.swift
//  parking-rental-app
//
//

import UIKit

final class RegistrationCarRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension RegistrationCarRouter: RegistrationCarRoutingLogic {
    func routeToHome() {
        view?.navigationController?.pushViewController(OnboardingAssembly.build(), animated: true)
    }
}
