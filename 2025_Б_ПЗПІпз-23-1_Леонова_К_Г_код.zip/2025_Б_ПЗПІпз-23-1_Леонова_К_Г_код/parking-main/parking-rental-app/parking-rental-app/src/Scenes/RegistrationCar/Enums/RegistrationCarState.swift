//
//  RegistrationCarState.swift
//  parking-rental-app
//
//

enum RegistrationCarState {
    case stable
    case carSetupFailure
}
