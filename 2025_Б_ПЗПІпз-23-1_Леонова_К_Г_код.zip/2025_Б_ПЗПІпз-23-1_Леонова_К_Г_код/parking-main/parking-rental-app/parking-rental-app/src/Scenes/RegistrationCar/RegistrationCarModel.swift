//
//  RegistrationCarModel.swift
//  parking-rental-app
//
//

import UIKit

enum RegistrationCarModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Home {
        struct Request {
            let carModel: String
            let carRegistryNumber: String
        }
        struct Response { }
        struct ViewModel { }
    }
    
    enum CarSetupFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
