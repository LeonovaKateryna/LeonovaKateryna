//
//  SettingsRouter.swift
//  parking-rental-app
//
//

import UIKit

final class SettingsRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension SettingsRouter: SettingsRoutingLogic {
    func routeToMore() {
        self.view?.navigationController?.popViewController(animated: true)
    }
}
