//
//  UpdateCarState.swift
//  parking-rental-app
//
//

enum UpdateCarState {
    case stable
    case carUpdateFailure
    case carUpdateSuccess
}
