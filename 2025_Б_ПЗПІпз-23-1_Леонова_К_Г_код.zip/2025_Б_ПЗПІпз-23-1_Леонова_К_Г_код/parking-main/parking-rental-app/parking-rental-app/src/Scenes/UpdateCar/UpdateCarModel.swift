//
//  UpdateCarModel.swift
//  parking-rental-app
//
//

import UIKit

enum UpdateCarModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Profile {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum UpdateCarRequest {
        struct Request {
            let carID: String
            let newModel: String
            let newRegistryNumber: String
        }
        struct Response { }
        struct ViewModel { }
    }
    
    enum CarUpdateFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
