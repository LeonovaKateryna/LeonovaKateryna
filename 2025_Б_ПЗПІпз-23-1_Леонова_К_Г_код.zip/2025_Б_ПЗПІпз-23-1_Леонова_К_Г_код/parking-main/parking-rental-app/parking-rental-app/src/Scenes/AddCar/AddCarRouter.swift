//
//  AddCarRouter.swift
//  parking-rental-app
//
//

import UIKit

final class AddCarRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension AddCarRouter: AddCarRoutingLogic {
    func routeToAccountCars() {
        view?.navigationController?.popViewController(animated: true)
    }
}
