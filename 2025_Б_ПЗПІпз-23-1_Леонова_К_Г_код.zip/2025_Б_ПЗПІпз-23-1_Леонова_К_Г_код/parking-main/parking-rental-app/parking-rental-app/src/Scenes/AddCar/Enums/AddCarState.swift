//
//  AddCarState.swift
//  parking-rental-app
//
//

enum AddCarState {
    case stable
    case carSetupFailure
}
