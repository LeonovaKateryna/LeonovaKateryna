//
//  AddCarModel.swift
//  parking-rental-app
//
//

import UIKit

enum AddCarModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum AccountCars {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum AddCarRequest {
        struct Request {
            let model: String
            let registryNumber: String
        }
        struct Response { }
        struct ViewModel { }
    }
    
    enum AddCarFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
