//
//  NotAuthMoreAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum NotAuthMoreAssembly {
    static func build() -> UIViewController {
        let router: NotAuthMoreRouter = NotAuthMoreRouter()
        let presenter: NotAuthMorePresenter = NotAuthMorePresenter()
        let interactor: NotAuthMoreInteractor = NotAuthMoreInteractor(presenter: presenter)
        let viewController: NotAuthMoreViewController = NotAuthMoreViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
