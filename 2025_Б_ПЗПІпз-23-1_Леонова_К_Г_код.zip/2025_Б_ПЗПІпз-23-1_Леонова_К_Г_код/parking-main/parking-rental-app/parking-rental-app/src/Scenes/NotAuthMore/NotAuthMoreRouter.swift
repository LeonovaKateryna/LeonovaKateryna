//
//  NotAuthMoreRouter.swift
//  parking-rental-app
//
//

import UIKit

final class NotAuthMoreRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension NotAuthMoreRouter: NotAuthMoreRoutingLogic {
    func routeToNotAuthSettings() {
        view?.navigationController?.pushViewController(NotAuthSettingsAssembly.build(), animated: true)
    }
    
    func routeToNotAuthContactDevs() {
        let vc = NotAuthContactDevsAssembly.build()
        vc.modalPresentationStyle = .overFullScreen
        view?.navigationController?.present(vc, animated: true)
    }
}
