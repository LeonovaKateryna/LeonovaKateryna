//
//  NotAuthMorePresenter.swift
//  parking-rental-app
//
//

final class NotAuthMorePresenter {
    // MARK: - Properties
    weak var view: NotAuthMoreDisplayLogic?
}

// MARK: - PresentationLogic
extension NotAuthMorePresenter: NotAuthMorePresentationLogic {
    func presentStart(_ response: Model.Start.Response) {
        view?.displayStart(Model.Start.ViewModel())
    }
    
    func presentNotAuthSettings(_ response: Model.NotAuthSettings.Response) {
        view?.displayNotAuthSettings(NotAuthMoreModel.NotAuthSettings.ViewModel())
    }
    
    func presentNotAuthContactDevs(_ response: Model.NotAuthContactDevs.Response) {
        view?.displayNotAuthContactDevs(NotAuthMoreModel.NotAuthContactDevs.ViewModel())
    }
}
