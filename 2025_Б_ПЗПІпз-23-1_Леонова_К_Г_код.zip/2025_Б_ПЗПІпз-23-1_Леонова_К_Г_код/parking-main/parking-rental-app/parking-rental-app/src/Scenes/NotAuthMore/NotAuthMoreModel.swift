//
//  NotAuthMoreModel.swift
//  parking-rental-app
//
//

import UIKit

enum NotAuthMoreModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum NotAuthSettings {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum NotAuthContactDevs {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
