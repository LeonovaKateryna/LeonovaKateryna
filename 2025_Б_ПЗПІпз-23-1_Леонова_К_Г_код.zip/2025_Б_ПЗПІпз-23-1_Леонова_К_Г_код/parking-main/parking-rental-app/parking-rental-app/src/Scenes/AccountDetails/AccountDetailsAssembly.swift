//
//  AccountDetailsAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum AccountDetailsAssembly {
    static func build() -> UIViewController {
        let router: AccountDetailsRouter = AccountDetailsRouter()
        let presenter: AccountDetailsPresenter = AccountDetailsPresenter()
        let interactor: AccountDetailsInteractor = AccountDetailsInteractor(presenter: presenter)
        let viewController: AccountDetailsViewController = AccountDetailsViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
