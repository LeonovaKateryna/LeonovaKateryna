//
//  AccountDetailsState.swift
//  parking-rental-app
//
//

enum AccountDetailsState {
    case loading
    case loaded
    case error
}
