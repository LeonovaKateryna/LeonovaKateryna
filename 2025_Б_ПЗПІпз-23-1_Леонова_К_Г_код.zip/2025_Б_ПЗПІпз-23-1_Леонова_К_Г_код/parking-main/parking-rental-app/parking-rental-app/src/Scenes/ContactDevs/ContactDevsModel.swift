//
//  ContactDevsModel.swift
//  parking-rental-app
//
//

import UIKit

enum ContactDevsModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum More {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum GitHubLink {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
