//
//  NotAuthSettingsRouter.swift
//  parking-rental-app
//
//

import UIKit

final class NotAuthSettingsRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension NotAuthSettingsRouter: NotAuthSettingsRoutingLogic {
    func routeToNotAuthMore() {
        view?.navigationController?.popViewController(animated: true)
    }
}
