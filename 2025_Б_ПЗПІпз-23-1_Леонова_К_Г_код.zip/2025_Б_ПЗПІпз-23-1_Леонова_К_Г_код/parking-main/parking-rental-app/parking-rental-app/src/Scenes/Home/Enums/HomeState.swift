//
//  HomeState.swift
//  parking-rental-app
//
//

enum HomeState {
    case loading
    case loaded
    case error
    case noData
}
