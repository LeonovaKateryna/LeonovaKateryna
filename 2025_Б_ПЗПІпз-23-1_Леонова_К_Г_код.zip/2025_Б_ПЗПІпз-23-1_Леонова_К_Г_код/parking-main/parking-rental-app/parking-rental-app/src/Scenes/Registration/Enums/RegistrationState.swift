//
//  RegistrationState.swift
//  parking-rental-app
//
//

enum RegistrationState {
    case stable
    case registrationFailure
}
