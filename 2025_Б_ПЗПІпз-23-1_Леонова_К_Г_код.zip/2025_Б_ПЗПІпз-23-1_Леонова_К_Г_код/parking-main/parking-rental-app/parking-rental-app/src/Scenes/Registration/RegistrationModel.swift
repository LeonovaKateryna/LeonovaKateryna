//
//  RegistrationModel.swift
//  parking-rental-app
//
//

import UIKit

enum RegistrationModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum RegistrationCar {
        struct Request {
            let name: String
            let email: String
            let password: String
        }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Login {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum RegistrationFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
