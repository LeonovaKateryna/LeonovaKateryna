//
//  NotAuthContactDevsAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum NotAuthContactDevsAssembly {
    static func build() -> UIViewController {
        let router: NotAuthContactDevsRouter = NotAuthContactDevsRouter()
        let presenter: NotAuthContactDevsPresenter = NotAuthContactDevsPresenter()
        let interactor: NotAuthContactDevsInteractor = NotAuthContactDevsInteractor(presenter: presenter)
        let viewController: NotAuthContactDevsViewController = NotAuthContactDevsViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
