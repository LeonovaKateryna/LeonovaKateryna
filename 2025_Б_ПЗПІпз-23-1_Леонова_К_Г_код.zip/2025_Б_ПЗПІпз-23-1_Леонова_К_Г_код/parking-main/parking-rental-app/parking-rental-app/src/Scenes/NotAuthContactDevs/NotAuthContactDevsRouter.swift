//
//  NotAuthContactDevsRouter.swift
//  parking-rental-app
//
//

import UIKit

final class NotAuthContactDevsRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension NotAuthContactDevsRouter: NotAuthContactDevsRoutingLogic {
    func routeToNotAuthMore() {
        self.view?.dismiss(animated: true)
    }
    
    func routeToGitHubLink() {
        guard let gitUrl = URL(string: "https://github.com/FoxFromFuture/parking") else { return }
        UIApplication.shared.open(gitUrl)
    }
}
