//
//  NotAuthContactDevsModel.swift
//  parking-rental-app
//
//

import UIKit

enum NotAuthContactDevsModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum NotAuthMore {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum GitHubLink {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
