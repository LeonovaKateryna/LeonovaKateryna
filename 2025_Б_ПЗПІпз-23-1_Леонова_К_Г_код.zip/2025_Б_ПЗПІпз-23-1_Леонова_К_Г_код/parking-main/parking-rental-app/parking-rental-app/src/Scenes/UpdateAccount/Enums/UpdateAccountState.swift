//
//  UpdateAccountState.swift
//  parking-rental-app
//
//

enum UpdateAccountState {
    case stable
    case accountUpdateFailure
    case accountUpdateSuccess
}
