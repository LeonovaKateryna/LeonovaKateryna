//
//  UpdateAccountModel.swift
//  parking-rental-app
//
//

import UIKit

enum UpdateAccountModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum AccountDetails {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum UpdateAccountRequest {
        struct Request {
            let name: String
            let email: String
            let password: String
        }
        struct Response { }
        struct ViewModel { }
    }
    
    enum UpdateAccountFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
