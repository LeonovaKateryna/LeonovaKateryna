//
//  UpdateAccountRouter.swift
//  parking-rental-app
//
//

import UIKit

final class UpdateAccountRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension UpdateAccountRouter: UpdateAccountRoutingLogic {
    func routeToAccountDetails() {
        view?.navigationController?.popViewController(animated: true)
    }
}
