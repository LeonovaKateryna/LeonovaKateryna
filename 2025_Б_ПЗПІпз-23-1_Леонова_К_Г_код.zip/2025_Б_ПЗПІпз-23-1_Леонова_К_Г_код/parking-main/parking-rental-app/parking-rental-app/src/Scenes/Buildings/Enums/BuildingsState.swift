//
//  BuildingsState.swift
//  parking-rental-app
//
//

enum BuildingsState {
    case loading
    case loaded
    case error
}
