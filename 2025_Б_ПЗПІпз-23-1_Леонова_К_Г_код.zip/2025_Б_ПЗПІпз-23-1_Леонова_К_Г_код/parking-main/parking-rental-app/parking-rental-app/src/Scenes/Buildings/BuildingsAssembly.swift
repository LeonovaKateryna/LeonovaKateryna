//
//  BuildingsAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum BuildingsAssembly {
    static func build() -> UIViewController {
        let router: BuildingsRouter = BuildingsRouter()
        let presenter: BuildingsPresenter = BuildingsPresenter()
        let interactor: BuildingsInteractor = BuildingsInteractor(presenter: presenter)
        let viewController: BuildingsViewController = BuildingsViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
