//
//  FAQAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum FAQAssembly {
    static func build() -> UIViewController {
        let router: FAQRouter = FAQRouter()
        let presenter: FAQPresenter = FAQPresenter()
        let interactor: FAQInteractor = FAQInteractor(presenter: presenter)
        let viewController: FAQViewController = FAQViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
