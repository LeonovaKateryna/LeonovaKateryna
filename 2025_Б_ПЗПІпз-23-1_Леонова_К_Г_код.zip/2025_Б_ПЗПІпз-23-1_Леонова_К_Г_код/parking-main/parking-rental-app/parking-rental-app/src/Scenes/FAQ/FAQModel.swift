//
//  FAQModel.swift
//  parking-rental-app
//
//

import UIKit

enum FAQModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum More {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
