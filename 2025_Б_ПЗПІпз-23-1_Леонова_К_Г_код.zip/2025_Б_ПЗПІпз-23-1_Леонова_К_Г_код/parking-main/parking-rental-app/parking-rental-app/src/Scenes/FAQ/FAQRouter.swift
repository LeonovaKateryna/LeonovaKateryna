//
//  FAQRouter.swift
//  parking-rental-app
//
//

import UIKit

final class FAQRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension FAQRouter: FAQRoutingLogic {
    func routeToMore() {
        self.view?.navigationController?.popViewController(animated: true)
    }
}
