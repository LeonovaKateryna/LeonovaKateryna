//
//  FAQInteractor.swift
//  parking-rental-app
//
//

import UIKit

final class FAQInteractor {
    // MARK: - Private Properties
    private let presenter: FAQPresentationLogic
    
    // MARK: - Initializers
    init(presenter: FAQPresentationLogic) {
        self.presenter = presenter
    }
}

// MARK: - BusinessLogic
extension FAQInteractor: FAQBusinessLogic {
    func loadStart(_ request: Model.Start.Request) {
        presenter.presentStart(Model.Start.Response())
    }
    
    func loadMore(_ request: Model.More.Request) {
        presenter.presentMore(FAQModel.More.Response())
    }
}
