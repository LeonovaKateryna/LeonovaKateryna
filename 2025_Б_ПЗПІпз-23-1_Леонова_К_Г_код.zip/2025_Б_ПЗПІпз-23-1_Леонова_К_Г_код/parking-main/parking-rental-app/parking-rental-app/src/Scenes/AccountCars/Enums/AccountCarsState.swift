//
//  AccountCarsState.swift
//  parking-rental-app
//
//

enum AccountCarsState {
    case loading
    case loaded
    case error
    case carsLimit
    case addCarActive
}
