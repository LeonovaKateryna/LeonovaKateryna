//
//  AccountCarsAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum AccountCarsAssembly {
    static func build() -> UIViewController {
        let router: AccountCarsRouter = AccountCarsRouter()
        let presenter: AccountCarsPresenter = AccountCarsPresenter()
        let interactor: AccountCarsInteractor = AccountCarsInteractor(presenter: presenter)
        let viewController: AccountCarsViewController = AccountCarsViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
