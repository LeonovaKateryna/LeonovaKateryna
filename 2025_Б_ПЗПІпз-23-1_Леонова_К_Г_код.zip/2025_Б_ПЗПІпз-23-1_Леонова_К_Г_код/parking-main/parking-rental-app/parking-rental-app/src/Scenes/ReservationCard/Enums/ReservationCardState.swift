//
//  ReservationCardState.swift
//  parking-rental-app
//
//

enum ReservationCardState {
    case loading
    case loaded
    case error
    case reservationsLimit
    case reservationsLimitForTime
    case weekendLimit
}
