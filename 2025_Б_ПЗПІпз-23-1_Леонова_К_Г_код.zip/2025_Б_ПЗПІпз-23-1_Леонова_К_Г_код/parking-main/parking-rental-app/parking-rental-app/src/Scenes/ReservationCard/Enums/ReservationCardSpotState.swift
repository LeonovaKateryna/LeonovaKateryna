//
//  ReservationCardSpotState.swift
//  parking-rental-app
//
//

enum ReservationCardSpotState {
    case freeSpot
    case reservedSpot
}
