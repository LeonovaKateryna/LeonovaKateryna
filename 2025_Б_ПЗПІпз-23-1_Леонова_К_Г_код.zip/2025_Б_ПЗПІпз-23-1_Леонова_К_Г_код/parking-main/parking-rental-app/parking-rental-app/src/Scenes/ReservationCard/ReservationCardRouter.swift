//
//  ReservationCardRouter.swift
//  parking-rental-app
//
//

import UIKit

final class ReservationCardRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension ReservationCardRouter: ReservationCardRoutingLogic {
    
}
