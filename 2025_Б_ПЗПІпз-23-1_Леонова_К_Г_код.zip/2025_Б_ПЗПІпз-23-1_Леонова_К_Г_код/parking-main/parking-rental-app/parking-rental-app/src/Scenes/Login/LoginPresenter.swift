//
//  LoginPresenter.swift
//  parking-rental-app
//
//

final class LoginPresenter {
    // MARK: - Properties
    weak var view: LoginDisplayLogic?
}

// MARK: - PresentationLogic
extension LoginPresenter: LoginPresentationLogic {
    func presentStart(_ response: Model.Start.Response) {
        view?.displayStart(Model.Start.ViewModel())
    }
    
    func presentHome(_ response: Model.Home.Response) {
        view?.displayHome(Model.Home.ViewModel())
    }
    
    func presentRegistration(_ response: Model.Registration.Response) {
        view?.displayRegistration(Model.Registration.ViewModel())
    }
    
    func presentLoginFailure(_ response: LoginModel.LoginFailure.Response) {
        view?.displayLoginFailure(LoginModel.LoginFailure.ViewModel())
    }
}
