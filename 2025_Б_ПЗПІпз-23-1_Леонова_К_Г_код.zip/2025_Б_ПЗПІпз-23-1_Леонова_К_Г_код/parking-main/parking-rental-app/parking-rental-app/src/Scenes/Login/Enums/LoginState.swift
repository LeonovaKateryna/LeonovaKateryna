//
//  LoginState.swift
//  parking-rental-app
//
//

enum LoginState {
    case stable
    case loginFailure
}
