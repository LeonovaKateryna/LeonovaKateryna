//
//  SplashAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum SplashAssembly {
    static func build() -> UIViewController {
        let router: SplashRouter = SplashRouter()
        let presenter: SplashPresenter = SplashPresenter()
        let interactor: SplashInteractor = SplashInteractor(presenter: presenter)
        let viewController: SplashViewController = SplashViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
