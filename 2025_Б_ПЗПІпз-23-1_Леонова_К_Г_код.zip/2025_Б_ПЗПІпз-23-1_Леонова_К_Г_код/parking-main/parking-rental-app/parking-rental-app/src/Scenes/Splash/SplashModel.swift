//
//  SplashModel.swift
//  parking-rental-app
//
//

import UIKit

enum SplashModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Home {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Login {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
