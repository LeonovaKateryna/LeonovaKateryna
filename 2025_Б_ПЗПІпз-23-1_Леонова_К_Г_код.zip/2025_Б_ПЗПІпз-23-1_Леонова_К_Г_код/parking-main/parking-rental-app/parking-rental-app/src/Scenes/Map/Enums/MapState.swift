//
//  MapState.swift
//  parking-rental-app
//
//

enum MapState {
    case loading
    case loaded
    case loadingError
    case reloadingError
}
