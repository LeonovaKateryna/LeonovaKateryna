//
//  CarDetailsModel.swift
//  parking-rental-app
//
//

import UIKit

enum CarDetailsModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum CarDetails {
        struct Request {
            let carID: String
        }
        struct Response {
            let car: Car
            let isOnlyOneCarLasts: Bool
        }
        struct ViewModel {
            let model: String
            let registryNumber: String
            let isOnlyOneCarLasts: Bool
        }
    }
    
    enum CarDetailsFailure {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum AccountCars {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum UpdateCar {
        struct Request {
            let carID: String
        }
        struct Response {
            let carID: String
        }
        struct ViewModel {
            let carID: String
        }
        struct RouteData {
            let carID: String
        }
    }
    
    enum DeleteCar {
        struct Request {
            let carID: String
        }
        struct Response { }
        struct ViewModel { }
    }
}
