//
//  CarDetailsProtocols.swift
//  parking-rental-app
//
//

// MARK: - DisplayLogic
protocol CarDetailsDisplayLogic: AnyObject {
    typealias Model = CarDetailsModel
    func displayStart(_ viewModel: Model.Start.ViewModel)
    func displayCarDetails(_ viewModel: Model.CarDetails.ViewModel)
    func displayAccountCars(_ viewModel: Model.AccountCars.ViewModel)
    func displayUpdateCar(_ viewModel: Model.UpdateCar.ViewModel)
    func displayDeleteCar(_ viewModel: Model.DeleteCar.ViewModel)
    func displayCarDetailsFailure(_ viewModel: Model.CarDetailsFailure.ViewModel)
}

// MARK: - BusinessLogic
protocol CarDetailsBusinessLogic {
    typealias Model = CarDetailsModel
    func loadStart(_ request: Model.Start.Request)
    func loadCarDetails(_ request: Model.CarDetails.Request)
    func loadAccountCars(_ request: Model.AccountCars.Request)
    func loadUpdateCar(_ request: Model.UpdateCar.Request)
    func loadDeleteCar(_ request: Model.DeleteCar.Request)
}

// MARK: - PresentationLogic
protocol CarDetailsPresentationLogic {
    typealias Model = CarDetailsModel
    func presentStart(_ response: Model.Start.Response)
    func presentCarDetails(_ response: Model.CarDetails.Response)
    func presentAccountCars(_ response: Model.AccountCars.Response)
    func presentUpdateCar(_ response: Model.UpdateCar.Response)
    func presentDeleteCar(_ response: Model.DeleteCar.Response)
    func presentCarDetailsFailure(_ response: Model.CarDetailsFailure.Response)
}

// MARK: - RoutingLogic
protocol CarDetailsRoutingLogic {
    typealias Model = CarDetailsModel
    func routeToAccountCars()
    func routeToUpdateCar(_ routeData: Model.UpdateCar.RouteData)
}
