//
//  CarDetailsState.swift
//  parking-rental-app
//
//

enum CarDetailsState {
    case loading
    case loaded
    case error
    case deleteCarLimit
    case deleteCarActive
}
