//
//  OnboardingModel.swift
//  parking-rental-app
//
//

import UIKit

enum OnboardingModel {
    
    enum Start {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
    
    enum Home {
        struct Request { }
        struct Response { }
        struct ViewModel { }
    }
}
