//
//  OnboardingPresenter.swift
//  parking-rental-app
//
//

final class OnboardingPresenter {
    // MARK: - Properties
    weak var view: OnboardingDisplayLogic?
}

// MARK: - PresentationLogic
extension OnboardingPresenter: OnboardingPresentationLogic {
    func presentStart(_ response: Model.Start.Response) {
        view?.displayStart(Model.Start.ViewModel())
    }
    
    func presentHome(_ response: Model.Home.Response) {
        view?.displayHome(OnboardingModel.Home.ViewModel())
    }
}
