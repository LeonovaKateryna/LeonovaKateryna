//
//  OnboardingRouter.swift
//  parking-rental-app
//
//

import UIKit

final class OnboardingRouter {
    // MARK: - Properties
    weak var view: UIViewController?
}

// MARK: - RoutingLogic
extension OnboardingRouter: OnboardingRoutingLogic {
    func routeToHome() {
        view?.navigationController?.pushViewController(TabBarController(), animated: true)
    }
}
