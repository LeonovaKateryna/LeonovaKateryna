//
//  OnboardingAssembly.swift
//  parking-rental-app
//
//

import UIKit

enum OnboardingAssembly {
    static func build() -> UIViewController {
        let router: OnboardingRouter = OnboardingRouter()
        let presenter: OnboardingPresenter = OnboardingPresenter()
        let interactor: OnboardingInteractor = OnboardingInteractor(presenter: presenter)
        let viewController: OnboardingViewController = OnboardingViewController(
            router: router,
            interactor: interactor
        )
        
        router.view = viewController
        presenter.view = viewController
        
        return viewController
    }
}
