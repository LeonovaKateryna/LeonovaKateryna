//
//  OnCanvasCoordsModel.swift
//  parking-rental-app
//
//

import Foundation

struct OnCanvasCoords: Decodable {
    let x: Int
    let y: Int
}
