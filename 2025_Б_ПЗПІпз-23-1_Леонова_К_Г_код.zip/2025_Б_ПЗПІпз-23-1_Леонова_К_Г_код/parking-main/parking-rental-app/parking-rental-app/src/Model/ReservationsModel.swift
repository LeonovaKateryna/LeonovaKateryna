//
//  ReservationsModel.swift
//  parking-rental-app
//
//

import Foundation

struct Reservation: Decodable {
    let id: String
    let carId: String
    let employeeId: String
    let parkingSpotId: String
    let startTime: String
    let endTime: String
}
