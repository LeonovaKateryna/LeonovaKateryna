//
//  CarsModel.swift
//  parking-rental-app
//
//

import Foundation

struct CarsApiResponse: Decodable {
    let cars: [Car]
}

struct Car: Decodable {
    let id: String
    let ownerId: String
    let model: String
    let lengthMeters: Double
    let weightTons: Double
    let registryNumber: String
}
