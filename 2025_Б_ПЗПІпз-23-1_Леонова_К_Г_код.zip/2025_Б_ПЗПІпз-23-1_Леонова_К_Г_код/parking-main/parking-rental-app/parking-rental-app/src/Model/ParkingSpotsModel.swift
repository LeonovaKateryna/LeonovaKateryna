//
//  ParkingSpotsModel.swift
//  parking-rental-app
//
//

import Foundation

struct ParkingSpot: Decodable {
    let id: String
    let levelId: String
    let buildingId: String
    let parkingNumber: String
    let isAvailable: Bool
    let isFree: Bool
    let canvas: Canvas
    let onCanvasCoords: OnCanvasCoords
}
