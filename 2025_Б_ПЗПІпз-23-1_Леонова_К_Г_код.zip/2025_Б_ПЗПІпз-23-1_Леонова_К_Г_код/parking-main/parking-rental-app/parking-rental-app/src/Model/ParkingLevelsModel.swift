//
//  ParkingLevelsModel.swift
//  parking-rental-app
//
//

import Foundation

struct ParkingLevel: Decodable {
    let id: String
    let buildingId: String
    let levelNumber: Int
    let numberOfSpots: Int
    let canvas: Canvas
}
