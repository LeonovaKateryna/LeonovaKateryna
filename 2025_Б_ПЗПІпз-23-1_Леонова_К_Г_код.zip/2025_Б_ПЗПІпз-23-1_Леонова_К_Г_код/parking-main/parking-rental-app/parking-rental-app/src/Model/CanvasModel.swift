//
//  CanvasModel.swift
//  parking-rental-app
//
//

import Foundation

struct Canvas: Decodable {
    let width: Int
    let height: Int
}
