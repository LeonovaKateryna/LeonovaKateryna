//
//  ThemeManager.swift
//  parking-rental-app
//
//

import Foundation

protocol ThemeManagerProtocol {
    var theme: Theme { get set }
}

final class ThemeManager: ThemeManagerProtocol {
    
    private var storage: UserDefaultsContainer!
    
    init(storage: UserDefaultsContainer = UserDefaultsService()) {
        self.storage = storage
    }
    
    var theme: Theme {
        get {
            Theme(rawValue: self.storage.theme) ?? .device
        }
        set {
            self.storage.theme = newValue.rawValue
        }
    }
}
